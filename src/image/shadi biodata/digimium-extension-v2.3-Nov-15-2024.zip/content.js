(function () {
  const style = document.createElement("style");
  document.documentElement.insertBefore(
    style,
    document.documentElement.firstChild
  );

  const hostname = window.location.hostname;

  // Applying CSS rules for semrush.com
  if (hostname.includes("semrush.com")) {
    style.textContent = `
            /* Hide specific button on semrush.com */
            button.srf-dropdown-label.srf-nav-link {
                display: none;
            }
            /* Make the navigation bar transparent */
            .srf-navbar__right {
                opacity: 0;
            }
        `;
  }

  // Applying CSS rules for getmerlin.in
  if (hostname.includes("getmerlin.in")) {
    style.textContent += `
            /* Reduce opacity for specific container on getmerlin.in */
            .relative.flex.flex-1.flex-col.justify-end.gap-3.overflow-hidden {
                opacity: 0;
            }
        `;
  }
})();

// Event listener which recieves the code when button is clicked
window.addEventListener("message", (event) => {
  if (!event.data || event.data.type !== "TRIGGER_PASTE") return;

  chrome.runtime.sendMessage({ type: "PASTE_CODE" });
});

console.log('Content script loaded!');
