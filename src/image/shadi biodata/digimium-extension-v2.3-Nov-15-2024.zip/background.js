// Function to clear toolzbuy.com cookies
function clearToolzBuyCookies() {
  chrome.cookies.getAll({ domain: ".toolzbuy.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear semrush.com cookies
function clearSemrushCookies() {
  chrome.cookies.getAll({ domain: ".semrush.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear getmerlin.in cookies
function clearMerlinCookies() {
  chrome.cookies.getAll({ domain: ".getmerlin.in" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear chatgpt.com cookies
function clearChatGPTCookies() {
  chrome.cookies.getAll({ domain: ".chatgpt.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear elements.digimiumtools.com cookies
function clearElementsDigimiumCookies() {
  chrome.cookies.getAll({ domain: ".elements.digimiumtools.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear vecteezy.com cookies
function clearVecteezyCookies() {
  chrome.cookies.getAll({ domain: ".vecteezy.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Function to clear storyblocks.com cookies
function clearStoryBlocksCookies() {
  chrome.cookies.getAll({ domain: ".storyblocks.com" }, function (cookies) {
    for (let cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        cookie.domain +
        cookie.path;
      chrome.cookies.remove({ url: url, name: cookie.name });
    }
  });
}

// Set an alarm to clear cookies every 120 minutes for all sites
chrome.alarms.create("clearCookies", {
  delayInMinutes: 1,
  periodInMinutes: 120,
});

// Listen for the alarm and clear cookies when it fires
chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === "clearCookies") {
    clearToolzBuyCookies();
    clearSemrushCookies();
    clearMerlinCookies();
    clearElementsDigimiumCookies();
    clearVecteezyCookies();
    clearStoryBlocksCookies();
  }
});

// Attempt to detect browser close by checking if the last window was closed
let windowCount = 0;

chrome.windows.onCreated.addListener(() => {
  windowCount++;
});

chrome.windows.onRemoved.addListener(() => {
  windowCount--;
  if (windowCount === 0) {
    clearToolzBuyCookies();
    clearSemrushCookies();
    clearMerlinCookies();
    clearChatGPTCookies();
    clearElementsDigimiumCookies();
    clearVecteezyCookies();
    clearStoryBlocksCookies();
  }
});

// Initialize window count
chrome.windows.getAll({}, (windows) => {
  windowCount = windows.length;
});

// Redirect balochseotools.com and toolzbuy.com to digimiumtools.com
chrome.webRequest.onBeforeRequest.addListener(
  function (details) {
    return {
      redirectUrl: details.url
        .replace(
          /^(https?:\/\/)(www\.)?(members\.)?balochseotools\.com/,
          "$1digimiumtools.com"
        )
        .replace(
          /^(https?:\/\/)(www\.)?(app\.)?toolzbuy\.com/,
          "$1digimiumtools.com"
        ),
    };
  },
  {
    urls: [
      "*://balochseotools.com/*",
      "*://www.balochseotools.com/*",
      "*://members.balochseotools.com/*",
      "*://toolzbuy.com/*",
      "*://www.toolzbuy.com/*",
      "*://app.toolzbuy.com/*",
    ],
    types: ["main_frame"],
  },
  ["blocking"]
);

//message listener which recieves the code from content js and handles it
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "PASTE_CODE") {
    handlePasteClick();
  }
});
